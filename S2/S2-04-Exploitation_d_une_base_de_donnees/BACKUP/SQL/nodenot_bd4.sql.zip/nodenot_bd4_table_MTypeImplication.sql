
-- --------------------------------------------------------

--
-- Structure de la table `MTypeImplication`
--

CREATE TABLE `MTypeImplication` (
  `id` smallint(5) NOT NULL DEFAULT '0',
  `libelleType` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MTypeImplication`
--

INSERT INTO `MTypeImplication` (`id`, `libelleType`) VALUES
(0, 'Autre raison'),
(1, 'Humain'),
(2, 'Deux roues'),
(3, 'Véhicule');
