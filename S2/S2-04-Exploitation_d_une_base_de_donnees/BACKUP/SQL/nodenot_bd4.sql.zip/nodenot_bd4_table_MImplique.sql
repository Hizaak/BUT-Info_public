
-- --------------------------------------------------------

--
-- Structure de la table `MImplique`
--

CREATE TABLE `MImplique` (
  `code` int(10) NOT NULL DEFAULT '0',
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type_code_implique` smallint(5) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MImplique`
--

INSERT INTO `MImplique` (`code`, `libelle`, `type_code_implique`) VALUES
(0, 'Autre', 0),
(1, 'Pieton moins 10 ans', 1),
(2, 'Pieton plus 10 ans', 1),
(3, 'Bicyclette', 2),
(4, 'Cyclomoteur', 2),
(5, 'Moto', 3),
(6, 'Voiture legere', 3),
(7, 'Poids lourd', 3),
(8, 'Bus', 3),
(9, 'Tram, Engin', 3);
