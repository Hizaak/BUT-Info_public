
-- --------------------------------------------------------

--
-- Structure de la table `MIntemperie`
--

CREATE TABLE `MIntemperie` (
  `code` int(10) NOT NULL DEFAULT '0',
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MIntemperie`
--

INSERT INTO `MIntemperie` (`code`, `libelle`) VALUES
(0, 'Beau temps'),
(1, 'Pluie forte'),
(2, 'Pluie legere'),
(3, 'Neige'),
(4, 'Grele'),
(5, 'Brouillard'),
(6, 'Vent fort tempete'),
(7, 'Inconnu');
