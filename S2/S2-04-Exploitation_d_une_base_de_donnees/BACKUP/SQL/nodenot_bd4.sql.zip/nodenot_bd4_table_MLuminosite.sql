
-- --------------------------------------------------------

--
-- Structure de la table `MLuminosite`
--

CREATE TABLE `MLuminosite` (
  `code` int(10) NOT NULL DEFAULT '0',
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type_luminosite` int(10) NOT NULL DEFAULT '0',
  `libelle_luminosite` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MLuminosite`
--

INSERT INTO `MLuminosite` (`code`, `libelle`, `type_luminosite`, `libelle_luminosite`) VALUES
(1, 'Jour', 1, 'Jour'),
(2, 'Demi jour', 1, 'Jour'),
(3, 'Nuit eclairee', 2, 'Nuit'),
(4, 'Nuit eclairee insuffisant', 2, 'Nuit'),
(5, 'Nuit sans eclairage', 2, 'Nuit');
