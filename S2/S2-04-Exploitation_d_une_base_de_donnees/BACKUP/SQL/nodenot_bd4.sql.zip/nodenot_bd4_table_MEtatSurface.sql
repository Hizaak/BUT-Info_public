
-- --------------------------------------------------------

--
-- Structure de la table `MEtatSurface`
--

CREATE TABLE `MEtatSurface` (
  `code_etat_surface` int(10) NOT NULL DEFAULT '0',
  `libelle_etat_surface` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `type_code_etat_surface` int(10) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MEtatSurface`
--

INSERT INTO `MEtatSurface` (`code_etat_surface`, `libelle_etat_surface`, `type_code_etat_surface`) VALUES
(1, 'Humide', 2),
(2, 'Mouillee', 2),
(3, 'Enneigee', 3),
(4, 'Verglacee', 3),
(5, 'Gras boueux', 3),
(6, 'Gravillons', 2),
(7, 'Sec Normal', 1);
