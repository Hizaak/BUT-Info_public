
--
-- Index pour les tables déchargées
--

--
-- Index pour la table `MAccident`
--
ALTER TABLE `MAccident`
  ADD PRIMARY KEY (`accident_id`),
  ADD KEY `MAccident_cause` (`cause_id`),
  ADD KEY `MAccident_Date` (`date_id`),
  ADD KEY `MAccident_EtatSurface` (`etat_surface_id`),
  ADD KEY `MAccident_Intemp` (`intemp_id`),
  ADD KEY `MAccident_Lieu` (`lieu_id`),
  ADD KEY `MAccident_luminosite` (`lum_id`),
  ADD KEY `MAccident_Implique` (`impliq_id`);

--
-- Index pour la table `MCause`
--
ALTER TABLE `MCause`
  ADD PRIMARY KEY (`Cause`);

--
-- Index pour la table `MDate`
--
ALTER TABLE `MDate`
  ADD PRIMARY KEY (`date_id`);

--
-- Index pour la table `MEtatSurface`
--
ALTER TABLE `MEtatSurface`
  ADD PRIMARY KEY (`code_etat_surface`),
  ADD KEY `EtatSurface_type` (`type_code_etat_surface`);

--
-- Index pour la table `MImplique`
--
ALTER TABLE `MImplique`
  ADD PRIMARY KEY (`code`),
  ADD KEY `Implique_type` (`type_code_implique`);

--
-- Index pour la table `MIntemperie`
--
ALTER TABLE `MIntemperie`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `MLieu`
--
ALTER TABLE `MLieu`
  ADD PRIMARY KEY (`lieu_id`);

--
-- Index pour la table `MLuminosite`
--
ALTER TABLE `MLuminosite`
  ADD PRIMARY KEY (`code`);

--
-- Index pour la table `MTypeEtatSurface`
--
ALTER TABLE `MTypeEtatSurface`
  ADD PRIMARY KEY (`id_etat_surface`);

--
-- Index pour la table `MTypeImplication`
--
ALTER TABLE `MTypeImplication`
  ADD PRIMARY KEY (`id`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `MAccident`
--
ALTER TABLE `MAccident`
  ADD CONSTRAINT `MAccident_Date` FOREIGN KEY (`date_id`) REFERENCES `MDate` (`date_id`),
  ADD CONSTRAINT `MAccident_EtatSurface` FOREIGN KEY (`etat_surface_id`) REFERENCES `MEtatSurface` (`code_etat_surface`),
  ADD CONSTRAINT `MAccident_Implique` FOREIGN KEY (`impliq_id`) REFERENCES `MImplique` (`code`),
  ADD CONSTRAINT `MAccident_Intemp` FOREIGN KEY (`intemp_id`) REFERENCES `MIntemperie` (`code`),
  ADD CONSTRAINT `MAccident_Lieu` FOREIGN KEY (`lieu_id`) REFERENCES `MLieu` (`lieu_id`),
  ADD CONSTRAINT `MAccident_cause` FOREIGN KEY (`cause_id`) REFERENCES `MCause` (`Cause`),
  ADD CONSTRAINT `MAccident_luminosite` FOREIGN KEY (`lum_id`) REFERENCES `MLuminosite` (`code`);

--
-- Contraintes pour la table `MEtatSurface`
--
ALTER TABLE `MEtatSurface`
  ADD CONSTRAINT `EtatSurface_type` FOREIGN KEY (`type_code_etat_surface`) REFERENCES `MTypeEtatSurface` (`id_etat_surface`);

--
-- Contraintes pour la table `MImplique`
--
ALTER TABLE `MImplique`
  ADD CONSTRAINT `Implique_type` FOREIGN KEY (`type_code_implique`) REFERENCES `MTypeImplication` (`id`);
