
-- --------------------------------------------------------

--
-- Structure de la table `MTypeEtatSurface`
--

CREATE TABLE `MTypeEtatSurface` (
  `id_etat_surface` int(10) NOT NULL DEFAULT '0',
  `libelle_type_code_etat_surface` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MTypeEtatSurface`
--

INSERT INTO `MTypeEtatSurface` (`id_etat_surface`, `libelle_type_code_etat_surface`) VALUES
(1, 'Normal'),
(2, 'Dangereux'),
(3, 'T Dangereux');
