
-- --------------------------------------------------------

--
-- Structure de la table `MCause`
--

CREATE TABLE `MCause` (
  `Cause` int(10) NOT NULL DEFAULT '0',
  `libelle` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `MCause`
--

INSERT INTO `MCause` (`Cause`, `libelle`) VALUES
(1, 'En intersection'),
(2, 'En section'),
(3, 'Depassement interdit ou dangereux'),
(4, 'Non respect des panneaux d interdiction'),
(5, 'Maitrise du vehicule'),
(6, 'Stationnement'),
(7, 'Pieton'),
(8, 'Causes humaines'),
(11, 'non respect feux tricolores'),
(12, 'non respect des signaux'),
(13, 'non respect du stop'),
(14, 'Non respect priorité a droite'),
(15, 'Non respect priorité a droite (avec feux clignotant)'),
(16, 'Non respect priorité de face'),
(17, 'Non respect du piéton en carrefour'),
(18, 'Mauvais positionnement (chgt de file)'),
(19, 'Non respect d\'une balise'),
(20, 'Circule sur le trottoir'),
(21, 'Roule à gauche'),
(22, 'Ecart sur le côté'),
(23, 'Demi-tour'),
(24, 'Roule en marche arrière'),
(25, 'Heurte un véhicule en stationnement'),
(26, 'Non respect du piéton en section'),
(27, 'Heurte un obstacle mobile'),
(28, 'Heurte un obstacle inerte'),
(31, 'Dépassement en carrefour'),
(32, 'Dépassement a droite'),
(33, 'Dépassement en virage'),
(34, 'Dépassement en 3eme position'),
(35, 'Queue de poisson'),
(36, 'Dépassement dangereux'),
(41, 'Sens interdit'),
(42, 'Tourne à gauche interdit'),
(43, 'Tourne à droite interdit'),
(51, 'Défaut de maîtrise'),
(52, 'Perte de contrôle'),
(53, 'Incident mécanique'),
(61, 'Ouverture d\'une portière'),
(62, 'Marche arrière pour stationner'),
(63, 'Quitte le stationnement'),
(64, 'Entre sur la chaussée'),
(65, 'Heurte véhicule en stationnement interdit'),
(66, 'Manoeuvre sur parking'),
(67, 'Va stationner a gauche'),
(71, 'Traverse hors passage'),
(72, 'Traverse sans précaution'),
(73, 'Joue ou travaille sur la chaussée'),
(74, 'Marche sur la chaussée'),
(75, 'Entre ou sort de véhicule en stationnement'),
(76, 'Piéton descendant d\'un t.c.'),
(77, 'Piéton montant dans un t.c.'),
(81, 'Ivresse'),
(82, 'Malaise'),
(83, 'Infirme'),
(85, 'Eclairage insuffisant du véhicule'),
(86, 'Eblouissement par les phares'),
(99, 'Indéterminée');
